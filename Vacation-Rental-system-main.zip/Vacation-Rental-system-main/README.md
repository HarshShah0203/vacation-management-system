# Vacation-Rental-system

I have recently completed a full-stack project using the MERN (MongoDB, Expresss. React.js. Node.js) stack. The project aims to create a dynamic and interactive web application, it involves building a database implementing back end functionality, and developing a responsive front-end interface using Reactjs

Create-react-app 
